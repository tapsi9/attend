<?php
include '../Includes/dbcon.php';
include '../Includes/session.php';

$studentName = trim(($_SESSION['firstName'] ?? '') . ' ' . ($_SESSION['lastName'] ?? ''));
$admissionNumber = $_SESSION['admissionNumber'] ?? '';
$classId = $_SESSION['classId'] ?? '';
$classArmId = $_SESSION['classArmId'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h4 class="card-title mb-3">Welcome, <?php echo htmlspecialchars($studentName); ?></h4>
                        <p class="mb-1"><strong>Admission Number:</strong> <?php echo htmlspecialchars($admissionNumber); ?></p>
                        <p class="mb-1"><strong>Class:</strong> <?php echo htmlspecialchars($classId); ?></p>
                        <p class="mb-4"><strong>Class Code / Subject:</strong> <?php echo htmlspecialchars($classArmId); ?></p>
                        <div class="d-flex gap-2 mb-3">
                            <a class="btn btn-primary" href="attendance.php">View Attendance</a>
                            <a class="btn btn-info text-white" href="grades.php">View Grades</a>
                            <a class="btn btn-outline-secondary" href="../index.php">Logout</a>
                        </div>
                        <p class="text-muted mb-0">This is a basic student landing page. You can extend it to show attendance history or other student resources.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>

