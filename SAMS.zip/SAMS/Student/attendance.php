<?php
include '../Includes/dbcon.php';
include '../Includes/session.php';

$admissionNumber = $_SESSION['admissionNumber'] ?? '';
$classId = $_SESSION['classId'] ?? '';
$classArmId = $_SESSION['classArmId'] ?? '';
$today = date('Y-m-d');

$statusMsg = '';
$rows = [];
$todayStatus = null;

// Active session term (fallback to 1 if none)
$sessionTermId = null;
$actRes = $conn->query("SELECT Id FROM tblsessionterm WHERE isActive = '1' LIMIT 1");
if ($actRes && $actRes->num_rows > 0) {
    $sessionTermId = $actRes->fetch_assoc()['Id'];
}
if (!$sessionTermId) {
    $fallback = $conn->query("SELECT Id FROM tblsessionterm ORDER BY Id DESC LIMIT 1");
    if ($fallback && $fallback->num_rows > 0) {
        $sessionTermId = $fallback->fetch_assoc()['Id'];
    }
}

// Handle mark present/absent
if (isset($_POST['mark_attendance']) && $admissionNumber && $classId && $classArmId) {
    $status = $_POST['mark_attendance'] === 'present' ? '1' : '0';
    // upsert today's record
    $exists = $conn->query("SELECT Id FROM tblattendance WHERE admissionNo='$admissionNumber' AND classId='$classId' AND classArmId='$classArmId' AND dateTimeTaken='$today'");
    if ($exists && $exists->num_rows > 0) {
        $conn->query("UPDATE tblattendance SET status='$status', sessionTermId='$sessionTermId' WHERE admissionNo='$admissionNumber' AND classId='$classId' AND classArmId='$classArmId' AND dateTimeTaken='$today'");
    } else {
        $conn->query("INSERT INTO tblattendance(admissionNo,classId,classArmId,sessionTermId,status,dateTimeTaken) VALUES('$admissionNumber','$classId','$classArmId','$sessionTermId','$status','$today')");
    }
    if ($conn->error) {
        $statusMsg = "<div class='alert alert-danger'>Could not update attendance. Please try again.</div>";
    } else {
        $statusMsg = "<div class='alert alert-success'>Today's attendance updated.</div>";
    }
}

// Today's status (after any update)
$ts = $conn->query("SELECT status FROM tblattendance WHERE admissionNo='$admissionNumber' AND classId='$classId' AND classArmId='$classArmId' AND dateTimeTaken='$today' LIMIT 1");
if ($ts && $ts->num_rows > 0) {
    $todayStatus = $ts->fetch_assoc()['status'] === '1' ? 'Present' : 'Absent';
}

// Build query based on filters
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $filterType = $_POST['filterType'] ?? 'all';
    $singleDate = $_POST['singleDate'] ?? '';
    $fromDate = $_POST['fromDate'] ?? '';
    $toDate = $_POST['toDate'] ?? '';

    $baseQuery = "SELECT tblattendance.Id,tblattendance.status,tblattendance.dateTimeTaken,
                        tblclass.className,tblclassarms.classArmName,tblsessionterm.sessionName,tblterm.termName
                  FROM tblattendance
                  INNER JOIN tblclass ON tblclass.Id = tblattendance.classId
                  INNER JOIN tblclassarms ON tblclassarms.Id = tblattendance.classArmId
                  INNER JOIN tblsessionterm ON tblsessionterm.Id = tblattendance.sessionTermId
                  INNER JOIN tblterm ON tblterm.Id = tblsessionterm.termId
                  WHERE tblattendance.admissionNo = '$admissionNumber'
                    AND tblattendance.classId = '$classId'
                    AND tblattendance.classArmId = '$classArmId'";

    if ($filterType === 'single' && $singleDate) {
        $baseQuery .= " AND tblattendance.dateTimeTaken = '$singleDate'";
    } elseif ($filterType === 'range' && $fromDate && $toDate) {
        $baseQuery .= " AND tblattendance.dateTimeTaken BETWEEN '$fromDate' AND '$toDate'";
    }

    $baseQuery .= " ORDER BY tblattendance.dateTimeTaken DESC";

    $rs = $conn->query($baseQuery);
    if ($rs) {
        while ($r = $rs->fetch_assoc()) {
            $rows[] = $r;
        }
        if (empty($rows)) {
            $statusMsg = "<div class='alert alert-warning'>No attendance records found for the selected filter.</div>";
        }
    } else {
        $statusMsg = "<div class='alert alert-danger'>Could not load attendance. Please try again.</div>";
    }
} else {
    // initial load: show latest 30
    $rs = $conn->query("SELECT tblattendance.Id,tblattendance.status,tblattendance.dateTimeTaken,
                        tblclass.className,tblclassarms.classArmName,tblsessionterm.sessionName,tblterm.termName
                        FROM tblattendance
                        INNER JOIN tblclass ON tblclass.Id = tblattendance.classId
                        INNER JOIN tblclassarms ON tblclassarms.Id = tblattendance.classArmId
                        INNER JOIN tblsessionterm ON tblsessionterm.Id = tblattendance.sessionTermId
                        INNER JOIN tblterm ON tblterm.Id = tblsessionterm.termId
                        WHERE tblattendance.admissionNo = '$admissionNumber'
                        AND tblattendance.classId = '$classId'
                        AND tblattendance.classArmId = '$classArmId'
                        ORDER BY tblattendance.dateTimeTaken DESC
                        LIMIT 30");
    if ($rs) {
        while ($r = $rs->fetch_assoc()) {
            $rows[] = $r;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Attendance</title>
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h3 class="mb-0">My Attendance</h3>
                    <a class="btn btn-outline-secondary btn-sm" href="index.php">Back</a>
                </div>
                <div class="card mb-4 shadow-sm">
                    <div class="card-body">
                        <?php echo $statusMsg; ?>
                        <div class="d-flex align-items-center mb-3 gap-2">
                            <form method="post" class="d-inline">
                                <input type="hidden" name="filterType" value="<?php echo htmlspecialchars($_POST['filterType'] ?? 'all'); ?>">
                                <button type="submit" name="mark_attendance" value="present" class="btn btn-success btn-sm">Mark Present (Today)</button>
                                <button type="submit" name="mark_attendance" value="absent" class="btn btn-outline-danger btn-sm">Mark Absent (Today)</button>
                            </form>
                            <?php if ($todayStatus): ?>
                                <span class="badge bg-info text-dark">Today: <?php echo $todayStatus; ?></span>
                            <?php else: ?>
                                <span class="text-muted">Today not marked</span>
                            <?php endif; ?>
                        </div>
                        <form method="post" class="row gy-3 gx-3 align-items-end">
                            <div class="col-md-3">
                                <label class="form-label">Filter</label>
                                <select name="filterType" id="filterType" class="form-control" onchange="toggleFilter(this.value)">
                                    <option value="all">All</option>
                                    <option value="single">By Single Date</option>
                                    <option value="range">By Date Range</option>
                                </select>
                            </div>
                            <div class="col-md-3 filter-single d-none">
                                <label class="form-label">Date</label>
                                <input type="date" name="singleDate" class="form-control">
                            </div>
                            <div class="col-md-3 filter-range d-none">
                                <label class="form-label">From</label>
                                <input type="date" name="fromDate" class="form-control">
                            </div>
                            <div class="col-md-3 filter-range d-none">
                                <label class="form-label">To</label>
                                <input type="date" name="toDate" class="form-control">
                            </div>
                            <div class="col-md-2">
                                <button type="submit" class="btn btn-success w-100">Apply</button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="card shadow-sm">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Date</th>
                                        <th>Status</th>
                                        <th>Session</th>
                                        <th>Term</th>
                                        <th>Class</th>
                                        <th>Class Code / Subject</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($rows)): ?>
                                        <tr><td colspan="7" class="text-center text-muted">No attendance records yet.</td></tr>
                                    <?php else: ?>
                                        <?php $sn=0; foreach ($rows as $row): $sn++; ?>
                                            <tr>
                                                <td><?php echo $sn; ?></td>
                                                <td><?php echo htmlspecialchars($row['dateTimeTaken']); ?></td>
                                                <td>
                                                    <?php if ($row['status'] == '1'): ?>
                                                        <span class="badge bg-success">Present</span>
                                                    <?php else: ?>
                                                        <span class="badge bg-danger">Absent</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo htmlspecialchars($row['sessionName']); ?></td>
                                                <td><?php echo htmlspecialchars($row['termName']); ?></td>
                                                <td><?php echo htmlspecialchars($row['className']); ?></td>
                                                <td><?php echo htmlspecialchars($row['classArmName']); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <script>
        function toggleFilter(type) {
            const single = document.querySelectorAll('.filter-single');
            const range = document.querySelectorAll('.filter-range');
            single.forEach(el => el.classList.add('d-none'));
            range.forEach(el => el.classList.add('d-none'));
            if (type === 'single') {
                single.forEach(el => el.classList.remove('d-none'));
            } else if (type === 'range') {
                range.forEach(el => el.classList.remove('d-none'));
            }
        }
        document.addEventListener('DOMContentLoaded', () => {
            toggleFilter(document.getElementById('filterType').value);
        });
    </script>
</body>
</html>

