<?php
error_reporting(0);
include '../Includes/dbcon.php';
include '../Includes/session.php';

$admissionNumber = $_SESSION['admissionNumber'] ?? '';
$classId = $_SESSION['classId'] ?? '';
$classArmId = $_SESSION['classArmId'] ?? '';

// Ensure grades table exists (noop if already created)
$conn->query("CREATE TABLE IF NOT EXISTS tblgrades (
  Id INT(10) NOT NULL AUTO_INCREMENT,
  admissionNo VARCHAR(255) NOT NULL,
  classId VARCHAR(10) NOT NULL,
  classArmId VARCHAR(10) NOT NULL,
  subject VARCHAR(255) NOT NULL,
  assessmentType VARCHAR(100) NOT NULL,
  score DECIMAL(10,2) NOT NULL,
  total DECIMAL(10,2) NOT NULL,
  sessionTermId VARCHAR(10) DEFAULT NULL,
  dateRecorded DATE NOT NULL,
  recordedBy INT(10) DEFAULT NULL,
  PRIMARY KEY (Id)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;");

$filterSubject = trim($_GET['subject'] ?? '');
$filterAssessment = trim($_GET['assessment'] ?? '');

$where = "WHERE admissionNo='$admissionNumber' AND classId='$classId' AND classArmId='$classArmId'";
if ($filterSubject) {
    $where .= " AND subject='" . $conn->real_escape_string($filterSubject) . "'";
}
if ($filterAssessment) {
    $where .= " AND assessmentType='" . $conn->real_escape_string($filterAssessment) . "'";
}

$rows = [];
$rs = $conn->query("SELECT subject, assessmentType, score, total, dateRecorded FROM tblgrades $where ORDER BY dateRecorded DESC");
if ($rs) {
    while ($r = $rs->fetch_assoc()) {
        $rows[] = $r;
    }
}

// averages
$avgPct = null;
$avgRes = $conn->query("SELECT SUM(score) as s, SUM(total) as t FROM tblgrades WHERE admissionNo='$admissionNumber' AND classId='$classId' AND classArmId='$classArmId'");
if ($avgRes) {
    $agg = $avgRes->fetch_assoc();
    if ($agg['t'] > 0) {
        $avgPct = round(($agg['s'] / $agg['t']) * 100, 2);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Grades</title>
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="mb-0">My Grades</h3>
            <a class="btn btn-outline-secondary btn-sm" href="index.php">Back</a>
        </div>
        <div class="card mb-4 shadow-sm">
            <div class="card-body">
                <form method="get" class="row g-3 align-items-end">
                    <div class="col-md-4">
                        <label class="form-label">Subject</label>
                        <input type="text" name="subject" class="form-control" value="<?php echo htmlspecialchars($filterSubject); ?>" placeholder="Filter by subject">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Assessment Type</label>
                        <input type="text" name="assessment" class="form-control" value="<?php echo htmlspecialchars($filterAssessment); ?>" placeholder="Quiz, Exam, ...">
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary w-100">Apply</button>
                    </div>
                    <div class="col-md-2">
                        <a href="grades.php" class="btn btn-outline-secondary w-100">Reset</a>
                    </div>
                </form>
            </div>
        </div>

        <div class="card shadow-sm">
            <div class="card-body">
                <?php if ($avgPct !== null): ?>
                    <div class="mb-3">
                        <span class="badge bg-info text-dark">Overall Average: <?php echo $avgPct; ?>%</span>
                    </div>
                <?php endif; ?>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Subject</th>
                                <th>Assessment</th>
                                <th>Score</th>
                                <th>Total</th>
                                <th>%</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($rows)): ?>
                                <tr><td colspan="7" class="text-center text-muted">No grades found.</td></tr>
                            <?php else: $sn=0; foreach ($rows as $row): $sn++; ?>
                                <tr>
                                    <td><?php echo $sn; ?></td>
                                    <td><?php echo htmlspecialchars($row['subject']); ?></td>
                                    <td><?php echo htmlspecialchars($row['assessmentType']); ?></td>
                                    <td><?php echo htmlspecialchars($row['score']); ?></td>
                                    <td><?php echo htmlspecialchars($row['total']); ?></td>
                                    <td><?php echo ($row['total'] > 0) ? round(($row['score']/$row['total'])*100,2).'%' : '-'; ?></td>
                                    <td><?php echo htmlspecialchars($row['dateRecorded']); ?></td>
                                </tr>
                            <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>

