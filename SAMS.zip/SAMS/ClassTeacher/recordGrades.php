<?php
error_reporting(0);
include '../Includes/dbcon.php';
include '../Includes/session.php';

// Ensure grades table exists (lightweight migration)
$conn->query("CREATE TABLE IF NOT EXISTS tblgrades (
  Id INT(10) NOT NULL AUTO_INCREMENT,
  admissionNo VARCHAR(255) NOT NULL,
  classId VARCHAR(10) NOT NULL,
  classArmId VARCHAR(10) NOT NULL,
  subject VARCHAR(255) NOT NULL,
  assessmentType VARCHAR(100) NOT NULL,
  score DECIMAL(10,2) NOT NULL,
  total DECIMAL(10,2) NOT NULL,
  sessionTermId VARCHAR(10) DEFAULT NULL,
  dateRecorded DATE NOT NULL,
  recordedBy INT(10) DEFAULT NULL,
  PRIMARY KEY (Id)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;");

// Active session term
$sessionTermId = null;
$actRes = $conn->query("SELECT Id FROM tblsessionterm WHERE isActive = '1' LIMIT 1");
if ($actRes && $actRes->num_rows > 0) {
    $sessionTermId = $actRes->fetch_assoc()['Id'];
} else {
    $fallback = $conn->query("SELECT Id FROM tblsessionterm ORDER BY Id DESC LIMIT 1");
    if ($fallback && $fallback->num_rows > 0) {
        $sessionTermId = $fallback->fetch_assoc()['Id'];
    }
}

$statusMsg = "";
$today = date("Y-m-d");

// Fetch class + class code/subject assigned to this teacher
$classQuery = "SELECT tblclass.Id AS classId, tblclass.className, tblclassarms.Id AS classArmId, tblclassarms.classArmName 
    FROM tblclassteacher
    INNER JOIN tblclass ON tblclass.Id = tblclassteacher.classId
    INNER JOIN tblclassarms ON tblclassarms.Id = tblclassteacher.classArmId
    WHERE tblclassteacher.Id = '{$_SESSION['userId']}'";
$classRow = $conn->query($classQuery)->fetch_assoc();
$classId = $classRow['classId'];
$classArmId = $classRow['classArmId'];

// Handle grade submission
if (isset($_POST['save_grades'])) {
    $subject = trim($_POST['subject'] ?? '');
    $assessmentType = trim($_POST['assessmentType'] ?? '');
    $dateRecorded = $_POST['dateRecorded'] ?: $today;
    $total = floatval($_POST['total'] ?? 0);
    $scores = $_POST['score'] ?? [];

    if (!$subject || !$assessmentType || $total <= 0) {
        $statusMsg = "<div class='alert alert-danger'>Please fill Subject, Assessment Type, and Total > 0.</div>";
    } else {
        foreach ($scores as $admissionNo => $scoreVal) {
            $score = is_numeric($scoreVal) ? floatval($scoreVal) : 0;
            $admissionNoSafe = $conn->real_escape_string($admissionNo);

            // upsert on (admissionNo, subject, assessmentType, dateRecorded)
            $exists = $conn->query("SELECT Id FROM tblgrades WHERE admissionNo='$admissionNoSafe' AND subject='$subject' AND assessmentType='$assessmentType' AND dateRecorded='$dateRecorded' LIMIT 1");
            if ($exists && $exists->num_rows > 0) {
                $rowId = $exists->fetch_assoc()['Id'];
                $conn->query("UPDATE tblgrades SET score='$score', total='$total', sessionTermId='$sessionTermId', recordedBy='{$_SESSION['userId']}' WHERE Id='$rowId'");
            } else {
                $conn->query("INSERT INTO tblgrades(admissionNo,classId,classArmId,subject,assessmentType,score,total,sessionTermId,dateRecorded,recordedBy) VALUES
                ('$admissionNoSafe','$classId','$classArmId','$subject','$assessmentType','$score','$total','$sessionTermId','$dateRecorded','{$_SESSION['userId']}')");
            }
        }

        if ($conn->error) {
            $statusMsg = "<div class='alert alert-danger'>Error saving grades. Please try again.</div>";
        } else {
            $statusMsg = "<div class='alert alert-success'>Grades saved.</div>";
        }
    }
}

// Fetch students in this teacher's class
$students = [];
$stuRes = $conn->query("SELECT firstName,lastName,otherName,admissionNumber FROM tblstudents WHERE classId='$classId' AND classArmId='$classArmId' ORDER BY firstName ASC");
if ($stuRes) {
    while ($r = $stuRes->fetch_assoc()) {
        $students[] = $r;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <link href="img/logo/attnlg.jpg" rel="icon">
  <title>Record Grades</title>
  <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
  <link href="css/ruang-admin.min.css" rel="stylesheet">
</head>
<body id="page-top">
  <div id="wrapper">
    <?php include "Includes/sidebar.php";?>
    <div id="content-wrapper" class="d-flex flex-column">
      <div id="content">
        <?php include "Includes/topbar.php";?>
        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Record Grades (<?php echo htmlspecialchars($classRow['className']); ?> - <?php echo htmlspecialchars($classRow['classArmName']); ?>)</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">Record Grades</li>
            </ol>
          </div>

          <div class="row">
            <div class="col-lg-12">
              <div class="card mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Enter Grades</h6>
                  <?php echo $statusMsg; ?>
                </div>
                <div class="card-body">
                  <form method="post">
                    <div class="form-row mb-3">
                      <div class="col-md-4">
                        <label>Subject / Class Code<span class="text-danger">*</span></label>
                        <input type="text" name="subject" class="form-control" required placeholder="e.g. IT304 or Math" value="<?php echo htmlspecialchars($_POST['subject'] ?? ''); ?>">
                      </div>
                      <div class="col-md-4">
                        <label>Assessment Type<span class="text-danger">*</span></label>
                        <input type="text" name="assessmentType" class="form-control" required placeholder="e.g. Quiz, Exam" value="<?php echo htmlspecialchars($_POST['assessmentType'] ?? ''); ?>">
                      </div>
                      <div class="col-md-2">
                        <label>Total Marks<span class="text-danger">*</span></label>
                        <input type="number" step="0.01" min="0" name="total" class="form-control" required value="<?php echo htmlspecialchars($_POST['total'] ?? '100'); ?>">
                      </div>
                      <div class="col-md-2">
                        <label>Date<span class="text-danger">*</span></label>
                        <input type="date" name="dateRecorded" class="form-control" required value="<?php echo htmlspecialchars($_POST['dateRecorded'] ?? $today); ?>">
                      </div>
                    </div>

                    <div class="table-responsive">
                      <table class="table table-striped">
                        <thead>
                          <tr>
                            <th>#</th>
                            <th>Student</th>
                            <th>Admission No</th>
                            <th>Score</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php if (empty($students)): ?>
                            <tr><td colspan="4" class="text-center text-muted">No students found for your class.</td></tr>
                          <?php else: $sn=0; foreach ($students as $stu): $sn++; ?>
                            <tr>
                              <td><?php echo $sn; ?></td>
                              <td><?php echo htmlspecialchars($stu['firstName']." ".$stu['lastName']); ?></td>
                              <td><?php echo htmlspecialchars($stu['admissionNumber']); ?></td>
                              <td style="max-width:120px;">
                                <input type="number" step="0.01" min="0" name="score[<?php echo htmlspecialchars($stu['admissionNumber']); ?>]" class="form-control" placeholder="0">
                              </td>
                            </tr>
                          <?php endforeach; endif; ?>
                        </tbody>
                      </table>
                    </div>

                    <button type="submit" name="save_grades" class="btn btn-success mt-3">Save Grades</button>
                  </form>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
      <?php include "Includes/footer.php";?>
    </div>
  </div>

  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <script src="../vendor/jquery/jquery.min.js"></script>
  <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>
  <script src="js/ruang-admin.min.js"></script>
</body>
</html>

