<?php
include 'Includes/dbcon.php';

$statusMsg = '';
$role = $_POST['role'] ?? '';

// fetch classes and class arms for selects
$classes = [];
$classArms = [];

$classRes = $conn->query("SELECT Id, className FROM tblclass ORDER BY className ASC");
if ($classRes) {
    while ($row = $classRes->fetch_assoc()) {
        $classes[] = $row;
    }
}

$armRes = $conn->query("SELECT Id, classId, classArmName FROM tblclassarms ORDER BY classArmName ASC");
if ($armRes) {
    while ($row = $armRes->fetch_assoc()) {
        $classArms[] = $row;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstName = $conn->real_escape_string($_POST['firstName'] ?? '');
    $lastName = $conn->real_escape_string($_POST['lastName'] ?? '');
    $otherName = $conn->real_escape_string($_POST['otherName'] ?? '');
    $email = $conn->real_escape_string($_POST['email'] ?? '');
    $phone = $conn->real_escape_string($_POST['phoneNo'] ?? '');
    $admissionNumber = $conn->real_escape_string($_POST['admissionNumber'] ?? '');
    $classId = $conn->real_escape_string($_POST['classId'] ?? '');
    $classArmId = $conn->real_escape_string($_POST['classArmId'] ?? '');
    $passwordInput = $_POST['password'] ?? '';
    $passwordHash = md5($passwordInput);
    $today = date('Y-m-d');

    if ($role === 'Administrator') {
        $exists = $conn->query("SELECT Id FROM tbladmin WHERE emailAddress = '$email'");
        if ($exists && $exists->num_rows > 0) {
            $statusMsg = "<div class='alert alert-danger'>Email already exists for an Administrator.</div>";
        } else {
            $insert = $conn->query("INSERT INTO tbladmin(firstName, lastName, emailAddress, password) VALUES('$firstName','$lastName','$email','$passwordHash')");
            $statusMsg = $insert ? "<div class='alert alert-success'>Administrator registered. You can now log in.</div>" : "<div class='alert alert-danger'>Error creating Administrator.</div>";
        }
    } elseif ($role === 'ClassTeacher') {
        $exists = $conn->query("SELECT Id FROM tblclassteacher WHERE emailAddress = '$email'");
        if ($exists && $exists->num_rows > 0) {
            $statusMsg = "<div class='alert alert-danger'>Email already exists for a Class Teacher.</div>";
        } else {
            $insert = $conn->query("INSERT INTO tblclassteacher(firstName, lastName, emailAddress, password, phoneNo, classId, classArmId, dateCreated) VALUES('$firstName','$lastName','$email','$passwordHash','$phone','$classId','$classArmId','$today')");
            $statusMsg = $insert ? "<div class='alert alert-success'>Class Teacher registered. You can now log in.</div>" : "<div class='alert alert-danger'>Error creating Class Teacher.</div>";
        }
    } elseif ($role === 'Student') {
        $exists = $conn->query("SELECT Id FROM tblstudents WHERE admissionNumber = '$admissionNumber'");
        if ($exists && $exists->num_rows > 0) {
            $statusMsg = "<div class='alert alert-danger'>Admission number already exists for a Student.</div>";
        } else {
            $insert = $conn->query("INSERT INTO tblstudents(firstName, lastName, otherName, admissionNumber, password, classId, classArmId, dateCreated) VALUES('$firstName','$lastName','$otherName','$admissionNumber','$passwordHash','$classId','$classArmId','$today')");
            $statusMsg = $insert ? "<div class='alert alert-success'>Student registered. You can now log in.</div>" : "<div class='alert alert-danger'>Error creating Student.</div>";
        }
    } else {
        $statusMsg = "<div class='alert alert-danger'>Please select a role.</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h3 class="mb-4">Create Account</h3>
                        <?php echo $statusMsg; ?>
                        <form method="post" id="registrationForm">
                            <div class="mb-3">
                                <label class="form-label">Role<span class="text-danger">*</span></label>
                                <select name="role" id="role" class="form-control" required onchange="toggleRole(this.value)">
                                    <option value="">--Select Role--</option>
                                    <option value="Administrator" <?php echo $role==='Administrator'?'selected':''; ?>>Administrator</option>
                                    <option value="ClassTeacher" <?php echo $role==='ClassTeacher'?'selected':''; ?>>ClassTeacher</option>
                                    <option value="Student" <?php echo $role==='Student'?'selected':''; ?>>Student</option>
                                </select>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">First Name<span class="text-danger">*</span></label>
                                    <input type="text" name="firstName" class="form-control" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Last Name<span class="text-danger">*</span></label>
                                    <input type="text" name="lastName" class="form-control" required>
                                </div>
                            </div>

                            <div class="row role-section role-student d-none">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Other Name</label>
                                    <input type="text" name="otherName" class="form-control" disabled>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Admission Number<span class="text-danger">*</span></label>
                                    <input type="text" name="admissionNumber" class="form-control" required disabled>
                                </div>
                            </div>

                            <div class="row role-section role-administrator role-classteacher mb-3 d-none">
                                <div class="col-md-12">
                                    <label class="form-label">Email<span class="text-danger">*</span></label>
                                    <input type="email" name="email" class="form-control" required disabled>
                                </div>
                            </div>

                            <div class="row role-section role-classteacher mb-3 d-none">
                                <div class="col-md-12">
                                    <label class="form-label">Phone Number<span class="text-danger">*</span></label>
                                    <input type="text" name="phoneNo" class="form-control" required disabled>
                                </div>
                            </div>

                            <div class="row role-section role-student role-classteacher d-none">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Class<span class="text-danger">*</span></label>
                                    <select name="classId" id="classId" class="form-control" onchange="filterArms('classId','classArmId')" required disabled>
                                        <option value="">--Select Class--</option>
                                        <?php foreach ($classes as $class): ?>
                                            <option value="<?php echo $class['Id']; ?>"><?php echo htmlspecialchars($class['className']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Class Arm<span class="text-danger">*</span></label>
                                    <select name="classArmId" id="classArmId" class="form-control" required disabled>
                                        <option value="">--Select Class Arm--</option>
                                        <?php foreach ($classArms as $arm): ?>
                                            <option value="<?php echo $arm['Id']; ?>" data-class="<?php echo $arm['classId']; ?>">
                                                <?php echo htmlspecialchars($arm['classArmName']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-md-12">
                                    <label class="form-label">Password<span class="text-danger">*</span></label>
                                    <input type="password" name="password" class="form-control" required>
                                </div>
                            </div>

                            <div class="d-flex align-items-center gap-3">
                                <button type="submit" class="btn btn-success">Register</button>
                                <a href="index.php" class="btn btn-link">Back to login</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
      function toggleRole(role) {
        const sections = document.querySelectorAll('.role-section');
        sections.forEach(sec => {
          const shouldShow = sec.classList.contains('role-' + role.toLowerCase());
          if (shouldShow) {
            sec.classList.remove('d-none');
            sec.querySelectorAll('input, select').forEach(el => el.disabled = false);
          } else {
            sec.classList.add('d-none');
            sec.querySelectorAll('input, select').forEach(el => el.disabled = true);
          }
        });
      }

      function filterArms(classSelectId, armSelectId) {
        const classId = document.getElementById(classSelectId).value;
        const armSelect = document.getElementById(armSelectId);
        let firstVisible = '';
        Array.from(armSelect.options).forEach(opt => {
          if (!opt.value) return;
          const matches = !classId || opt.dataset.class === classId;
          opt.hidden = !matches;
          if (matches && !firstVisible) firstVisible = opt.value;
        });
        if (classId) {
          armSelect.value = firstVisible || '';
        } else {
          armSelect.value = '';
        }
      }

      document.addEventListener('DOMContentLoaded', () => {
        const initialRole = document.getElementById('role').value;
        if (initialRole) toggleRole(initialRole);
      });
    </script>
</body>
</html>

